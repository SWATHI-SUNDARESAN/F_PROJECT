# Ambulance Signal System

    npm install
    npm start

Open http://localhost:3000
- /register   register an ambulance (get AMB-XXXXXXXX id)
- /emergency  verify id, search places, request green corridor (admin approves)
- /driver     pick on map, auto-activates corridor, optional drive simulation
- /admin      dashboard (default login: admin / admin123)

Requires internet for map tiles, OSRM routing, Nominatim and Overpass.
