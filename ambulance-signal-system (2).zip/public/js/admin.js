const API = location.protocol === 'file:' ? 'http://localhost:3000' : '';
let adminData = null;
let refreshInterval = null;
let modalMap = null;

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ==================== TRAFFIC SIGNAL ICON (Leaflet) ====================
function signalIcon(number, color) {
  const redC = color === 'red' ? '#FF0000' : '#4a0000';
  const yelC = color === 'yellow' ? '#FFD600' : '#4a4a00';
  const grnC = color === 'green' ? '#00FF00' : '#003a00';
  const box  = color === 'green' ? '#1a1a1a' : '#333';
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="48" viewBox="0 0 28 48">
    <rect x="11" y="36" width="6" height="12" rx="1" fill="#666"/>
    <rect x="1" y="1" width="26" height="35" rx="4" fill="${box}" stroke="#555" stroke-width="1"/>
    <circle cx="14" cy="9"  r="4.5" fill="${redC}"/>
    <circle cx="14" cy="19" r="4.5" fill="${yelC}"/>
    <circle cx="14" cy="29" r="4.5" fill="${grnC}"/>
    <circle cx="23" cy="5"  r="6" fill="#1a73e8" stroke="white" stroke-width="1.5"/>
    <text x="23" y="8.5" text-anchor="middle" font-size="8" font-weight="bold" fill="white" font-family="Arial">${number}</text>
  </svg>`;
  return L.divIcon({ html: svg, className: '', iconSize: [28, 48], iconAnchor: [14, 48], popupAnchor: [0, -48] });
}

function pinIcon(letter, color) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="36" height="48" viewBox="0 0 36 48">
    <path d="M18 0C8 0 0 8 0 18c0 14 18 30 18 30s18-16 18-30C36 8 28 0 18 0z" fill="${color}" stroke="white" stroke-width="2"/>
    <circle cx="18" cy="16" r="9" fill="white"/>
    <text x="18" y="21" text-anchor="middle" font-size="14" font-weight="bold" fill="${color}" font-family="Arial">${letter}</text>
  </svg>`;
  return L.divIcon({ html: svg, className: '', iconSize: [36, 48], iconAnchor: [18, 48], popupAnchor: [0, -48] });
}

// ==================== LOGIN ====================
async function adminLogin(e) {
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value.trim();
  try {
    const response = await fetch(`${API}/api/admin/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const result = await response.json();
    if (response.ok) {
      adminData = result.admin;
      document.getElementById('login-section').classList.add('hidden');
      document.getElementById('dashboard-section').classList.remove('hidden');
      document.getElementById('admin-name').textContent = `Welcome, ${result.admin.name}`;
      loadStats(); loadEmergencies(); loadAmbulances();
      refreshInterval = setInterval(() => { loadStats(); loadEmergencies(); }, 5000);
    } else {
      document.getElementById('login-alert').innerHTML = `<div class="alert alert-danger">❌ ${esc(result.error)}</div>`;
    }
  } catch (error) {
    document.getElementById('login-alert').innerHTML = '<div class="alert alert-danger">❌ Network error. Is the server running?</div>';
  }
}

function adminLogout() {
  if (refreshInterval) clearInterval(refreshInterval);
  adminData = null;
  document.getElementById('login-section').classList.remove('hidden');
  document.getElementById('dashboard-section').classList.add('hidden');
  document.getElementById('login-username').value = '';
  document.getElementById('login-password').value = '';
}

// ==================== STATS ====================
async function loadStats() {
  try {
    const response = await fetch(`${API}/api/admin/stats`);
    const stats = await response.json();
    document.getElementById('stat-ambulances').textContent = stats.totalAmbulances;
    document.getElementById('stat-total').textContent = stats.totalEmergencies;
    document.getElementById('stat-pending').textContent = stats.pendingEmergencies;
    document.getElementById('stat-approved').textContent = stats.approvedToday;
    document.getElementById('stat-corridors').textContent = stats.activeCorridors;
  } catch (error) { console.error('Stats error:', error); }
}

// ==================== TABS ====================
function switchTab(tabName, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.getElementById(`tab-${tabName}`).classList.add('active');
  btn.classList.add('active');
}

// ==================== EMERGENCIES ====================
async function loadEmergencies() {
  try {
    const response = await fetch(`${API}/api/admin/emergencies`);
    const emergencies = await response.json();
    const container = document.getElementById('emergencies-list');
    if (emergencies.length === 0) {
      container.innerHTML = '<div class="empty-state"><div class="icon">📭</div><h3>No emergency requests yet</h3><p>Requests will appear here.</p></div>';
      return;
    }
    container.innerHTML = emergencies.map(em => {
      const statusClass = em.signal_status === 'green_signal' ? 'approved' : em.signal_status === 'rejected' ? 'rejected' : '';
      const badge = em.signal_status === 'pending' ? '<span class="badge badge-pending">⏳ Pending</span>'
        : em.signal_status === 'green_signal' ? '<span class="badge badge-green">🟢 Green Signal</span>'
        : '<span class="badge badge-red">🔴 Rejected</span>';
      const corridorBadge = em.corridor_status === 'active' ? '<span class="corridor-badge corridor-active">🟢 CORRIDOR ACTIVE</span>'
        : em.corridor_status === 'completed' ? '<span class="corridor-badge corridor-inactive">✅ Completed</span>' : '';
      const priorityIcon = em.priority === 'critical' ? '🔴' : em.priority === 'high' ? '🟠' : '🟡';
      const hasRoute = em.source_address && em.destination_address;
      const signals = em.signals_data || [];
      const signalCount = em.signals_count || signals.length || 0;

      return `
        <div class="emergency-card ${statusClass}">
          <div class="emergency-card-header">
            <div><strong style="font-size:1.1rem;">${esc(em.vehicle_number)}</strong>
              <span style="color:var(--gray);margin-left:0.5rem;font-family:monospace;">${esc(em.unique_id)}</span> ${corridorBadge}</div>
            ${badge}
          </div>
          <div class="emergency-card-body">
            <div class="detail"><span>Hospital</span>${esc(em.hospital_name)}</div>
            <div class="detail"><span>Area</span>${esc(em.area)}</div>
            <div class="detail"><span>Driver</span>${esc(em.driver_name)} (${esc(em.driver_phone)})</div>
            <div class="detail"><span>Vehicle Type</span>${esc(em.vehicle_type)}</div>
            <div class="detail"><span>Priority</span>${priorityIcon} ${esc(em.priority)}</div>
            <div class="detail"><span>Requested</span>${new Date(em.requested_at).toLocaleString()}</div>
          </div>
          ${hasRoute ? `
            <div style="background:var(--light-gray);border-radius:8px;padding:0.75rem;margin-bottom:1rem;">
              <strong style="font-size:0.85rem;">📍 Route Details</strong>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;margin-top:0.5rem;font-size:0.85rem;">
                <div><strong>From:</strong> ${esc(em.source_address.split(',').slice(0,3).join(','))}</div>
                <div><strong>To:</strong> ${esc(em.destination_address.split(',').slice(0,3).join(','))}</div>
              </div>
              <div class="route-summary">
                <span class="route-chip">📏 ${esc(em.route_distance||'—')}</span>
                <span class="route-chip">⏱️ ${esc(em.route_duration||'—')}</span>
                <span class="route-chip" style="background:#f8d7da;color:#721c24;">🚦 ${signalCount} Signals</span>
                ${em.corridor_status==='active'?'<span class="route-chip" style="background:#d4edda;color:#155724;">🟢 Corridor Active</span>':''}
              </div>
              <button onclick="showRouteMap(${em.id})" class="btn btn-sm btn-primary" style="margin-top:0.5rem;">🗺️ View Route Map & Signals</button>
            </div>` : ''}
          ${em.signal_status === 'pending' ? `
            <div class="emergency-card-actions">
              <button onclick="approveEmergency(${em.id},${signalCount})" class="btn btn-success btn-sm" style="flex:1;">🟢 Activate Green Corridor (${signalCount} signals)</button>
              <button onclick="rejectEmergency(${em.id})" class="btn btn-danger btn-sm" style="flex:1;">🔴 Reject</button>
            </div>`
          : em.corridor_status === 'active' ? `
            <div class="emergency-card-actions">
              <button onclick="deactivateCorridor(${em.id})" class="btn btn-sm" style="flex:1;background:var(--gray);color:white;">⏹️ Deactivate Corridor</button>
            </div>`
          : `<div style="padding-top:0.75rem;border-top:1px solid var(--border);color:var(--gray);font-size:0.85rem;">
              ${em.admin_notes?'📝 '+esc(em.admin_notes):''}${em.responded_at?' • '+new Date(em.responded_at).toLocaleString():''}
            </div>`}
        </div>`;
    }).join('');
  } catch (error) { console.error('Emergencies error:', error); }
}

// ==================== ROUTE MAP MODAL (Leaflet) ====================
async function showRouteMap(emergencyId) {
  const modal = document.getElementById('map-modal');
  modal.classList.remove('hidden');
  modal.style.display = 'flex';
  document.getElementById('modal-info').innerHTML = '<div class="loading"><div class="spinner"></div><span>Loading route...</span></div>';
  document.getElementById('modal-signals').innerHTML = '';

  try {
    const response = await fetch(`${API}/api/admin/emergency/${emergencyId}`);
    const em = await response.json();
    if (!em.source_lat || !em.destination_lat) {
      document.getElementById('modal-info').innerHTML = '<div class="alert alert-warning">No route data available.</div>';
      return;
    }
    const signals = em.signals_data || [];
    const isGreen = em.corridor_status === 'active';

    // Build map
    const mapEl = document.getElementById('modal-map');
    if (modalMap) { modalMap.remove(); modalMap = null; }
    modalMap = L.map(mapEl).setView([em.source_lat, em.source_lng], 12);
    addBaseTiles(modalMap);

    // Draw route if polyline data exists
    if (em.route_polyline) {
      try {
        const coords = JSON.parse(em.route_polyline);
        const line = L.polyline(coords, { color: isGreen ? '#00cc00' : '#1a73e8', weight: 6, opacity: 0.85 }).addTo(modalMap);
        modalMap.fitBounds(line.getBounds(), { padding: [30, 30] });
      } catch(e) {
        // If polyline parsing fails, just use OSRM
        try {
          const url = `https://router.project-osrm.org/route/v1/driving/${em.source_lng},${em.source_lat};${em.destination_lng},${em.destination_lat}?overview=full&geometries=geojson`;
          const routeRes = await fetch(url);
          const routeData = await routeRes.json();
          if (routeData.code === 'Ok') {
            const coords = routeData.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
            const line = L.polyline(coords, { color: isGreen ? '#00cc00' : '#1a73e8', weight: 6, opacity: 0.85 }).addTo(modalMap);
            modalMap.fitBounds(line.getBounds(), { padding: [30, 30] });
          }
        } catch(e2) { /* skip route line */ }
      }
    } else {
      // Fetch route from OSRM
      try {
        const url = `https://router.project-osrm.org/route/v1/driving/${em.source_lng},${em.source_lat};${em.destination_lng},${em.destination_lat}?overview=full&geometries=geojson`;
        const routeRes = await fetch(url);
        const routeData = await routeRes.json();
        if (routeData.code === 'Ok') {
          const coords = routeData.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
          const line = L.polyline(coords, { color: isGreen ? '#00cc00' : '#1a73e8', weight: 6, opacity: 0.85 }).addTo(modalMap);
          modalMap.fitBounds(line.getBounds(), { padding: [30, 30] });
        }
      } catch(e) { /* skip */ }
    }

    // Source & Dest markers
    L.marker([em.source_lat, em.source_lng], { icon: pinIcon('A', '#28a745'), zIndexOffset: 1000 }).addTo(modalMap)
      .bindPopup('<strong>📍 Source</strong><br>' + esc((em.source_address||'').split(',').slice(0,3).join(',')));
    L.marker([em.destination_lat, em.destination_lng], { icon: pinIcon('B', '#dc3545'), zIndexOffset: 1000 }).addTo(modalMap)
      .bindPopup('<strong>🏥 Destination</strong><br>' + esc((em.destination_address||'').split(',').slice(0,3).join(',')));

    // Signal markers
    signals.forEach((s, i) => {
      const state = isGreen ? 'green' : 'red';
      L.marker([s.lat, s.lng], { icon: signalIcon(i + 1, state), zIndexOffset: 500 }).addTo(modalMap)
        .bindPopup(`<strong>🚦 Signal #${i+1}</strong><br>📍 ${esc(s.name)}<br>📌 ${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}<br><hr style="margin:4px 0">${isGreen ? '<span style="color:#00cc00;font-weight:bold;">🟢 GREEN</span>' : '<span style="color:#cc0000;font-weight:bold;">🔴 RED</span>'}`);
    });

    // Force map to resize
    setTimeout(() => modalMap.invalidateSize(), 200);

    // Info
    document.getElementById('modal-info').innerHTML = `
      <div class="route-info-grid" style="margin-top:1rem;">
        <div class="route-info-card"><div class="value">${esc(em.route_distance||'—')}</div><div class="label">Distance</div></div>
        <div class="route-info-card"><div class="value">${esc(em.route_duration||'—')}</div><div class="label">Duration</div></div>
        <div class="route-info-card signals"><div class="value">${signals.length}</div><div class="label">Traffic Signals</div></div>
        <div class="route-info-card corridor"><div class="value">${isGreen?'🟢 ACTIVE':em.corridor_status==='completed'?'✅ Done':'⏳ Pending'}</div><div class="label">Corridor</div></div>
      </div>
      <div style="font-size:0.85rem;margin-top:0.75rem;">
        <strong>From:</strong> ${esc((em.source_address||'').split(',').slice(0,3).join(','))}<br>
        <strong>To:</strong> ${esc((em.destination_address||'').split(',').slice(0,3).join(','))}
      </div>`;

    // Signal list
    if (signals.length > 0) {
      document.getElementById('modal-signals').innerHTML = `
        <details open style="margin-top:1rem;">
          <summary style="cursor:pointer;font-weight:600;">🚦 ${signals.length} Traffic Signals on Route</summary>
          <div class="signal-list">
            ${signals.map((s,i) => `
              <div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-bottom:1px solid var(--border);font-size:0.85rem;">
                <div style="width:12px;height:12px;border-radius:50%;background:${isGreen?'#00ff00':'#dc3545'};flex-shrink:0;${isGreen?'box-shadow:0 0 8px rgba(0,255,0,0.5);':''}"></div>
                <strong>#${i+1}</strong>
                <span style="flex:1;">${esc(s.name)}</span>
                <span style="font-size:0.75rem;font-weight:700;color:${isGreen?'green':'#dc3545'};">${isGreen?'🟢 GREEN':'🔴 RED'}</span>
              </div>`).join('')}
          </div>
        </details>`;
    }
  } catch (error) {
    document.getElementById('modal-info').innerHTML = '<div class="alert alert-danger">Failed to load route data.</div>';
  }
}

function closeMapModal(e) {
  if (e.target === e.currentTarget) {
    document.getElementById('map-modal').classList.add('hidden');
    document.getElementById('map-modal').style.display = 'none';
  }
}

// ==================== APPROVE / REJECT / DEACTIVATE ====================
async function approveEmergency(id, signalCount) {
  if (!confirm(`Activate GREEN CORRIDOR?\n\n${signalCount} traffic signals will be set to GREEN.\n\nProceed?`)) return;
  const notes = prompt('Admin notes (optional):') || `Green Corridor Activated — ${signalCount} signals GREEN`;
  try {
    const response = await fetch(`${API}/api/admin/emergency/${id}/approve`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ admin_notes: notes }),
    });
    const result = await response.json();
    if (response.ok) { alert(`🟢 GREEN CORRIDOR ACTIVATED!\n\n${result.message}`); loadEmergencies(); loadStats(); }
    else { alert(`Error: ${result.error}`); }
  } catch (error) { alert('Network error.'); }
}

async function rejectEmergency(id) {
  const notes = prompt('Reason for rejection:');
  if (notes === null) return;
  try {
    const response = await fetch(`${API}/api/admin/emergency/${id}/reject`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ admin_notes: notes || 'Not verified' }),
    });
    const result = await response.json();
    if (response.ok) { alert('🔴 Rejected.'); loadEmergencies(); loadStats(); }
    else { alert(`Error: ${result.error}`); }
  } catch (error) { alert('Network error.'); }
}

async function deactivateCorridor(id) {
  if (!confirm('Deactivate corridor? Signals return to normal.')) return;
  try {
    const response = await fetch(`${API}/api/admin/emergency/${id}/deactivate-corridor`, { method: 'PUT' });
    if (response.ok) { alert('✅ Corridor deactivated.'); loadEmergencies(); loadStats(); }
  } catch (error) { alert('Network error.'); }
}

// ==================== AMBULANCES TABLE ====================
async function loadAmbulances() {
  try {
    const response = await fetch(`${API}/api/admin/ambulances`);
    const ambulances = await response.json();
    const container = document.getElementById('ambulances-table');
    if (ambulances.length === 0) {
      container.innerHTML = '<div class="empty-state"><div class="icon">🚑</div><h3>No ambulances registered yet</h3></div>';
      return;
    }
    container.innerHTML = `<div class="table-wrapper"><table><thead><tr>
      <th>Unique ID</th><th>Vehicle No.</th><th>Hospital</th><th>Area</th><th>Driver</th><th>Phone</th><th>Type</th><th>Status</th><th>Registered</th><th>Action</th>
    </tr></thead><tbody>
      ${ambulances.map(a => `<tr>
        <td><code>${esc(a.unique_id)}</code></td><td><strong>${esc(a.vehicle_number)}</strong></td><td>${esc(a.hospital_name)}</td><td>${esc(a.area)}</td>
        <td>${esc(a.driver_name)}</td><td>${esc(a.driver_phone)}</td><td>${esc(a.vehicle_type)}</td>
        <td><span class="badge ${a.status==='active'?'badge-active':'badge-red'}">${esc(a.status)}</span></td>
        <td>${new Date(a.registered_at).toLocaleDateString()}</td>
        <td>${a.status==='active'?`<button onclick="deactivateAmbulance(${a.id})" class="btn btn-sm btn-danger">Deactivate</button>`:'<span style="color:var(--gray);">Inactive</span>'}</td>
      </tr>`).join('')}
    </tbody></table></div>`;
  } catch (error) { console.error('Ambulances error:', error); }
}

async function deactivateAmbulance(id) {
  if (!confirm('Deactivate this ambulance?')) return;
  try {
    const r = await fetch(`${API}/api/admin/ambulance/${id}/deactivate`, { method: 'PUT' });
    if (r.ok) { alert('Deactivated.'); loadAmbulances(); loadStats(); }
  } catch (e) { alert('Network error.'); }
}
