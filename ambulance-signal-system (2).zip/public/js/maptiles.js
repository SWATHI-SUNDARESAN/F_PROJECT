// Shared base-map helper: OpenStreetMap tiles, auto-fallback to CARTO if OSM refuses
// (OSM blocks requests that have no Referer, e.g. pages opened via file://).
function addBaseTiles(map) {
  if (typeof L === 'undefined') return;
  const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxZoom: 19
  }).addTo(map);

  let errors = 0, switched = false;
  osm.on('tileerror', () => {
    if (switched || ++errors < 3) return;
    switched = true;
    map.removeLayer(osm);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '© OpenStreetMap contributors © CARTO',
      subdomains: 'abcd', maxZoom: 19
    }).addTo(map);
  });

  if (location.protocol === 'file:') {
    console.warn('Opened via file:// — open http://localhost:3000 instead so map search/tiles work reliably.');
  }
}
