const API = location.protocol === 'file:' ? 'http://localhost:3000' : '';
let currentAmbulance = null;
let pollingInterval = null;
let map = null;
let routeLine = null;
let mapMarkers = [];
let sourceCoords = null;
let destCoords = null;
let routeData = null;
let detectedSignals = [];
let currentEmergencyId = null;
let searchMarkers = { source: null, dest: null };
let copyMaps = {};

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ==================== ICONS ====================
function trafficLightIcon(num, color) {
  const r = color==='red'?'#FF0000':'#4a0000';
  const y = color==='yellow'?'#FFD600':'#4a4a00';
  const g = color==='green'?'#00FF00':'#003a00';
  const bg = color==='green'?'#111':'#333';
  return L.divIcon({ className:'', iconSize:[30,50], iconAnchor:[15,50], popupAnchor:[0,-52],
    html:`<svg xmlns="http://www.w3.org/2000/svg" width="30" height="50" viewBox="0 0 30 50">
      <rect x="12" y="38" width="6" height="12" rx="1" fill="#777"/>
      <rect x="2" y="1" width="26" height="37" rx="5" fill="${bg}" stroke="#666" stroke-width="1"/>
      <circle cx="15" cy="9" r="5" fill="${r}"/><circle cx="15" cy="20" r="5" fill="${y}"/><circle cx="15" cy="31" r="5" fill="${g}"/>
      <circle cx="25" cy="5" r="7" fill="#1a73e8" stroke="#fff" stroke-width="1.5"/>
      <text x="25" y="9" text-anchor="middle" font-size="9" font-weight="bold" fill="#fff" font-family="Arial">${num}</text>
    </svg>`
  });
}
function mapPin(letter, color) {
  return L.divIcon({ className:'', iconSize:[38,50], iconAnchor:[19,50], popupAnchor:[0,-52],
    html:`<svg xmlns="http://www.w3.org/2000/svg" width="38" height="50" viewBox="0 0 38 50">
      <path d="M19 0C9 0 0 9 0 19c0 15 19 31 19 31s19-16 19-31C38 9 29 0 19 0z" fill="${color}" stroke="#fff" stroke-width="2"/>
      <circle cx="19" cy="17" r="10" fill="#fff"/>
      <text x="19" y="22" text-anchor="middle" font-size="15" font-weight="bold" fill="${color}" font-family="Arial">${letter}</text>
    </svg>`
  });
}

// ==================== HELPERS ====================
function showAlert(type, msg) {
  document.getElementById('alert-container').innerHTML = `<div class="alert alert-${type}">${msg}</div>`;
  setTimeout(() => document.getElementById('alert-container').innerHTML = '', 6000);
}
function showStep(id) {
  ['step-verify','step-emergency','step-waiting','step-result'].forEach(s => document.getElementById(s).classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}
function haversine(lat1,lng1,lat2,lng2) {
  const R=6371000, toR=x=>x*Math.PI/180;
  const a=Math.sin(toR(lat2-lat1)/2)**2+Math.cos(toR(lat1))*Math.cos(toR(lat2))*Math.sin(toR(lng2-lng1)/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

// ==================== SEARCH PLACE (type text + press Enter) ====================
async function searchPlace(which) {
  const input = document.getElementById(which === 'source' ? 'source-input' : 'dest-input');
  const statusEl = document.getElementById(which === 'source' ? 'source-status' : 'dest-status');
  const query = input.value.trim();

  if (!query) { showAlert('danger', '❌ Please type a place name'); return; }

  statusEl.innerHTML = '<span style="color:var(--gray);">🔍 Searching...</span>';

  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1&countrycodes=in`
    );
    const places = await res.json();

    if (!places.length) {
      statusEl.innerHTML = '<span class="not-found-badge">❌ Place not found. Try a different name.</span>';
      return;
    }

    const place = places[0];
    const lat = parseFloat(place.lat);
    const lng = parseFloat(place.lon);
    const name = place.display_name;
    const shortName = name.split(',').slice(0, 3).join(', ');

    if (which === 'source') {
      sourceCoords = { lat, lng, name };
    } else {
      destCoords = { lat, lng, name };
    }

    statusEl.innerHTML = `<span class="found-badge">✅ Found: ${esc(shortName)}</span>`;

    // Show on map
    if (map) {
      const icon = which === 'source' ? mapPin('A', '#28a745') : mapPin('B', '#dc3545');
      const label = which === 'source' ? '📍 START' : '🏥 DESTINATION';
      if (searchMarkers[which]) map.removeLayer(searchMarkers[which]);
      searchMarkers[which] = L.marker([lat, lng], { icon, zIndexOffset: 1000 }).addTo(map)
        .bindPopup(`<b>${label}</b><br>${esc(shortName)}`).openPopup();
      map.setView([lat, lng], 14);
    }

  } catch (e) {
    statusEl.innerHTML = '<span class="not-found-badge">❌ Search failed. Check internet.</span>';
  }
}

// ==================== STEP 1: VERIFY ====================
async function verifyAmbulance() {
  const uid = document.getElementById('unique_id').value.trim().toUpperCase();
  if (!uid) { showAlert('danger', '❌ Please enter your Ambulance Unique ID'); return; }
  try {
    const res = await fetch(`${API}/api/ambulances/lookup/${uid}`);
    const data = await res.json();
    if (!res.ok) { showAlert('danger', `❌ ${data.error}`); return; }
    currentAmbulance = data;
    document.getElementById('info-uid').textContent = data.unique_id;
    document.getElementById('info-vehicle').textContent = data.vehicle_number;
    document.getElementById('info-hospital').textContent = data.hospital_name;
    document.getElementById('info-area').textContent = data.area;
    document.getElementById('info-driver').textContent = data.driver_name;
    document.getElementById('info-type').textContent = data.vehicle_type;
    showStep('step-emergency');
    setTimeout(() => {
      if (map) { map.remove(); map = null; }
      map = L.map('route-map').setView([12.97, 77.59], 12);
      addBaseTiles(map);
    }, 200);
  } catch (e) { showAlert('danger', '❌ Network error'); }
}

// ==================== STEP 2: CALCULATE ROUTE ====================
async function calculateRoute() {
  if (!sourceCoords) { showAlert('danger', '❌ Please search for START point first (type place name and press Enter or click Search)'); return; }
  if (!destCoords) { showAlert('danger', '❌ Please search for DESTINATION first (type place name and press Enter or click Search)'); return; }

  const btn = document.getElementById('calcRouteBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Finding route & counting signals...';

  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${sourceCoords.lng},${sourceCoords.lat};${destCoords.lng},${destCoords.lat}?overview=full&geometries=geojson&steps=true`;
    const res = await fetch(url);
    const data = await res.json();

    if (data.code !== 'Ok') {
      showAlert('danger', '❌ No route found. Try different places.');
      btn.disabled = false; btn.textContent = '🗺️ Find Route & Count Traffic Signals'; return;
    }

    const route = data.routes[0];
    const polyCoords = route.geometry.coordinates.map(c => [c[1], c[0]]);
    const distKm = (route.distance / 1000).toFixed(1);
    const durMin = Math.round(route.duration / 60);

    // Clear old layers
    clearMap();

    // Draw route
    routeLine = L.polyline(polyCoords, { color: '#1a73e8', weight: 6, opacity: 0.8 }).addTo(map);
    map.fitBounds(routeLine.getBounds(), { padding: [50, 50] });

    // Start & End pins
    mapMarkers.push(
      L.marker([sourceCoords.lat, sourceCoords.lng], { icon: mapPin('A','#28a745'), zIndexOffset:1000 })
        .addTo(map).bindPopup(`<b>📍 START</b><br>${esc(sourceCoords.name.split(',').slice(0,3).join(','))}`),
      L.marker([destCoords.lat, destCoords.lng], { icon: mapPin('B','#dc3545'), zIndexOffset:1000 })
        .addTo(map).bindPopup(`<b>🏥 DESTINATION</b><br>${esc(destCoords.name.split(',').slice(0,3).join(','))}`)
    );

    // Save route data
    routeData = {
      source_address: sourceCoords.name, source_lat: sourceCoords.lat, source_lng: sourceCoords.lng,
      destination_address: destCoords.name, destination_lat: destCoords.lat, destination_lng: destCoords.lng,
      distance: `${distKm} km`, duration: `${durMin} mins`,
      polyline: JSON.stringify(polyCoords)
    };

    // Show info
    document.getElementById('route-distance').textContent = `${distKm} km`;
    document.getElementById('route-duration').textContent = `${durMin} mins`;

    // FIND TRAFFIC SIGNALS
    findSignals(route, polyCoords);

    document.getElementById('route-info').classList.remove('hidden');
    btn.disabled = false; btn.textContent = '🗺️ Recalculate Route';

  } catch (e) {
    showAlert('danger', '❌ Route failed. Check internet.');
    btn.disabled = false; btn.textContent = '🗺️ Find Route & Count Traffic Signals';
  }
}

function clearMap() {
  if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
  mapMarkers.forEach(m => map.removeLayer(m));
  mapMarkers = [];
  Object.keys(searchMarkers).forEach(k => {
    if (searchMarkers[k]) { map.removeLayer(searchMarkers[k]); searchMarkers[k] = null; }
  });
}

// ==================== FIND TRAFFIC SIGNALS ====================
function findSignals(route, polyCoords) {
  detectedSignals = [];

  // From OSRM steps — turns at intersections
  (route.legs[0].steps || []).forEach((step, idx) => {
    const m = step.maneuver || {};
    const loc = m.location;
    if (!loc) return;
    const type = m.type || '';
    const mod = m.modifier || '';
    const isTurn = ['turn','end of road','fork','roundabout turn','new name'].includes(type);
    const hasDir = ['left','right','slight left','slight right','sharp left','sharp right'].includes(mod);

    if (isTurn || hasDir) {
      const dup = detectedSignals.some(s => haversine(s.lat, s.lng, loc[1], loc[0]) < 80);
      if (!dup) {
        detectedSignals.push({ name: step.name || `${mod} ${type}`.trim() || `Junction ${idx+1}`, lat: loc[1], lng: loc[0] });
      }
    }
  });

  // At ~800m intervals
  let acc = 0;
  for (let i = 1; i < polyCoords.length; i++) {
    acc += haversine(polyCoords[i-1][0], polyCoords[i-1][1], polyCoords[i][0], polyCoords[i][1]);
    if (acc >= 800) {
      acc = 0;
      const dup = detectedSignals.some(s => haversine(s.lat, s.lng, polyCoords[i][0], polyCoords[i][1]) < 150);
      if (!dup) detectedSignals.push({ name: 'Traffic Signal', lat: polyCoords[i][0], lng: polyCoords[i][1] });
    }
  }

  // Sort by distance from source
  detectedSignals.sort((a,b) => haversine(sourceCoords.lat,sourceCoords.lng,a.lat,a.lng) - haversine(sourceCoords.lat,sourceCoords.lng,b.lat,b.lng));
  detectedSignals.forEach((s,i) => s.id = i+1);

  const count = detectedSignals.length;

  // Update BIG count
  document.getElementById('big-signal-count').textContent = count;
  document.getElementById('route-signals').textContent = count;
  document.getElementById('signal-count-text').textContent = count;

  // Place markers on map
  detectedSignals.forEach((s, i) => {
    const km = (haversine(sourceCoords.lat, sourceCoords.lng, s.lat, s.lng) / 1000).toFixed(1);
    const m = L.marker([s.lat, s.lng], { icon: trafficLightIcon(i+1, 'red'), zIndexOffset: 500 }).addTo(map);
    m.bindPopup(`<div style="min-width:180px"><b>🚦 Traffic Signal #${i+1}</b><br>📍 ${esc(s.name)}<br>📏 ${km} km from start<br><hr style="margin:4px 0"><b style="color:red">🔴 RED — Normal</b></div>`);
    mapMarkers.push(m);
  });

  // Build list
  document.getElementById('signal-list').innerHTML = detectedSignals.map((s, i) => {
    const km = (haversine(sourceCoords.lat, sourceCoords.lng, s.lat, s.lng) / 1000).toFixed(1);
    return `<div class="signal-item" onclick="zoomSignal(${i})">
      <div class="signal-dot"></div>
      <strong>#${i+1}</strong>
      <span style="flex:1">${esc(s.name)}</span>
      <span style="color:var(--gray);font-size:0.8rem">${km} km</span>
      <span>🔴</span>
    </div>`;
  }).join('');
}

function zoomSignal(i) {
  const s = detectedSignals[i];
  if (!s) return;
  map.setView([s.lat, s.lng], 17);
  mapMarkers.forEach(m => {
    if (m.getLatLng && Math.abs(m.getLatLng().lat - s.lat) < 0.0001) m.openPopup();
  });
}

// ==================== STEP 3: TRIGGER EMERGENCY ====================
async function triggerEmergency() {
  if (!routeData) { showAlert('danger', '❌ Calculate route first'); return; }
  document.getElementById('emergencyBtn').disabled = true;
  try {
    const res = await fetch(`${API}/api/emergency/trigger`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        unique_id: currentAmbulance.unique_id,
        source_address: routeData.source_address, source_lat: routeData.source_lat, source_lng: routeData.source_lng,
        destination_address: routeData.destination_address, destination_lat: routeData.destination_lat, destination_lng: routeData.destination_lng,
        route_distance: routeData.distance, route_duration: routeData.duration, route_polyline: routeData.polyline,
        signals_count: detectedSignals.length, signals_data: detectedSignals,
        priority: document.getElementById('priority').value
      })
    });
    const data = await res.json();
    if (!res.ok) { showAlert('danger', `❌ ${data.error}`); document.getElementById('emergencyBtn').disabled = false; return; }

    currentEmergencyId = data.emergency.id;
    showStep('step-waiting');
    document.getElementById('w-distance').textContent = routeData.distance;
    document.getElementById('w-duration').textContent = routeData.duration;
    document.getElementById('w-signals').textContent = detectedSignals.length;
    setTimeout(() => buildMapCopy('waiting-map', 'yellow'), 300);
    startPolling();
  } catch (e) { showAlert('danger', '❌ Network error'); document.getElementById('emergencyBtn').disabled = false; }
}

function buildMapCopy(elId, signalColor) {
  if (copyMaps[elId]) { copyMaps[elId].remove(); copyMaps[elId] = null; }
  const m2 = L.map(elId).setView([routeData.source_lat, routeData.source_lng], 12);
  addBaseTiles(m2);
  const coords = JSON.parse(routeData.polyline);
  const lc = signalColor === 'green' ? '#00cc00' : '#ffc107';
  L.polyline(coords, { color:lc, weight:6, opacity:0.85 }).addTo(m2);
  m2.fitBounds(L.polyline(coords).getBounds(), { padding:[30,30] });
  L.marker([routeData.source_lat, routeData.source_lng], { icon:mapPin('A','#28a745'), zIndexOffset:1000 }).addTo(m2);
  L.marker([routeData.destination_lat, routeData.destination_lng], { icon:mapPin('B','#dc3545'), zIndexOffset:1000 }).addTo(m2);
  detectedSignals.forEach((s,i) => {
    L.marker([s.lat, s.lng], { icon:trafficLightIcon(i+1, signalColor), zIndexOffset:500 }).addTo(m2)
      .bindPopup(`<b>🚦 #${i+1}</b> ${esc(s.name)}<br>${signalColor==='green'?'🟢 GREEN':'🟡 Pending'}`);
  });
  copyMaps[elId] = m2;
}

// ==================== STEP 4: POLL & RESULT ====================
function startPolling() {
  if (pollingInterval) clearInterval(pollingInterval);
  pollingInterval = setInterval(async () => {
    try {
      const res = await fetch(`${API}/api/emergency/status/${currentAmbulance.unique_id}`);
      const d = await res.json();
      if (!res.ok || d.id !== currentEmergencyId) return;
      if (d.signal_status === 'green_signal') { clearInterval(pollingInterval); showGreen(d); }
      else if (d.signal_status === 'rejected') { clearInterval(pollingInterval); showRejected(d); }
    } catch (e) {}
  }, 2000);
}

function showGreen(data) {
  showStep('step-result');
  const signals = data.signals_data || detectedSignals;
  const count = data.signals_count || signals.length;

  document.getElementById('result-content').innerHTML = `
    <div class="green-corridor-box">
      <div class="big-number">🟢 ${count}</div>
      <div class="label">Traffic Signals Set to GREEN!</div>
      <div style="margin-top:0.5rem;font-size:1.2rem;font-weight:700;">GREEN CORRIDOR ACTIVATED</div>
    </div>
    <div class="route-info-grid">
      <div class="route-info-card"><div class="value">${data.route_distance||routeData.distance}</div><div class="label">Distance</div></div>
      <div class="route-info-card"><div class="value">${data.route_duration||routeData.duration}</div><div class="label">Duration</div></div>
      <div class="route-info-card corridor"><div class="value">${count}</div><div class="label">GREEN Signals</div></div>
      <div class="route-info-card corridor"><div class="value">🟢 ACTIVE</div><div class="label">Corridor</div></div>
    </div>`;

  setTimeout(() => buildMapCopy('result-map', 'green'), 300);

  document.getElementById('result-signal-list').innerHTML = `
    <h3 style="margin:1rem 0 0.5rem;">🟢 All ${count} Signals — GREEN</h3>
    <div class="signal-list">${signals.map((s,i) => `
      <div class="signal-item"><div class="signal-dot green"></div><strong>#${i+1}</strong>
      <span style="flex:1">${esc(s.name)}</span><span style="color:green;font-weight:700">🟢 GREEN</span></div>`).join('')}
    </div>`;

  document.getElementById('final-green').classList.add('active-signal');
  document.title = '🟢 GREEN CORRIDOR ACTIVE';
}

function showRejected(data) {
  showStep('step-result');
  document.getElementById('result-content').innerHTML = `<div class="alert alert-danger" style="font-size:1.1rem;text-align:center;">🔴 <strong>REJECTED</strong></div>
    ${data.admin_notes?`<p style="text-align:center;color:var(--gray)">Reason: ${esc(data.admin_notes)}</p>`:''}`;
  document.getElementById('result-signal-list').innerHTML = '';
  document.getElementById('result-map').style.display = 'none';
  document.getElementById('final-red').classList.add('active-signal');
}

function resetEmergency() {
  if (pollingInterval) clearInterval(pollingInterval);
  currentAmbulance=null; sourceCoords=null; destCoords=null; routeData=null; detectedSignals=[]; currentEmergencyId=null;
  searchMarkers = { source: null, dest: null };
  Object.keys(copyMaps).forEach(k => { if (copyMaps[k]) { copyMaps[k].remove(); copyMaps[k] = null; } });
  document.getElementById('unique_id').value='';
  document.getElementById('source-input').value='';
  document.getElementById('dest-input').value='';
  document.getElementById('source-status').innerHTML='';
  document.getElementById('dest-status').innerHTML='';
  document.getElementById('emergencyBtn').disabled=false;
  document.getElementById('result-map').style.display='';
  if(map){map.remove();map=null;} mapMarkers=[];
  document.querySelectorAll('.signal-light').forEach(el=>el.classList.remove('active-signal'));
  document.title='Emergency — Ambulance Signal System';
  document.getElementById('alert-container').innerHTML='';
  document.getElementById('route-info').classList.add('hidden');
  document.getElementById('calcRouteBtn').textContent='🗺️ Find Route & Count Traffic Signals';
  showStep('step-verify');
}

document.getElementById('unique_id').addEventListener('keypress', e => { if(e.key==='Enter') verifyAmbulance(); });
