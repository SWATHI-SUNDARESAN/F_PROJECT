// ====================================================
// driver.js  –  OpenStreetMap / Leaflet driver panel
// ====================================================

const API = location.protocol === 'file:' ? 'http://localhost:3000' : '';

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ── state ──────────────────────────────────────────
let currentAmb    = null;   // selected ambulance object
let pickMode      = null;   // 'start' | 'dest' | null
let signalPickMode = false; // true when user is placing manual signals
let startLatLng   = null;
let destLatLng    = null;
let routeData     = null;   // { coords, distance, duration }
let osmSignals    = [];     // signals found via Overpass (OpenStreetMap)
let manualSignals = [];     // manually placed signals only
let signals       = [];     // osmSignals + manualSignals (rebuilt by refreshSignals)
let ambList       = [];     // active ambulances loaded from server
let corridorGreenUpTo = -1; // index of last green signal while corridor is active
let activeEmerID  = null;   // server emergency id once triggered

// ── Leaflet map objects ────────────────────────────
let map, startMarker, destMarker, routeLayer, ambMarker;
let signalLayers = [];

// ── simulation ─────────────────────────────────────
let simInterval  = null;
let simStep      = 0;

// ====================================================
// Map init
// ====================================================
function initMap() {
  map = L.map('map').setView([12.9716, 77.5946], 12);

  addBaseTiles(map);

  map.on('click', onMapClick);

  // Try geolocation
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      pos => map.setView([pos.coords.latitude, pos.coords.longitude], 14),
      () => {}
    );
  }
}

// ====================================================
// Ambulance list
// ====================================================
async function loadAmbulances() {
  try {
    const res  = await fetch(`${API}/api/admin/ambulances`);
    const list = await res.json();
    const sel  = document.getElementById('amb-select');
    ambList = list.filter(a => a.status === 'active');
    if (ambList.length === 0) {
      sel.innerHTML = '<option value="">No registered ambulances yet</option>';
      return;
    }
    sel.innerHTML = ambList.map(a =>
      `<option value="${esc(a.unique_id)}">${esc(a.vehicle_number)} — ${esc(a.hospital_name)} (${esc(a.unique_id)})</option>`
    ).join('');
  } catch (e) {
    showAlert('danger', '❌ Could not load ambulances. Is the server running?');
  }
}

function selectAmbulance() {
  const sel = document.getElementById('amb-select');
  if (!sel.value) { showAlert('danger', '❌ Pick an ambulance first'); return; }
  currentAmb = ambList.find(a => a.unique_id === sel.value);
  if (!currentAmb) { showAlert('danger', '❌ Ambulance not found'); return; }

  document.getElementById('amb-info').innerHTML = `
    <strong>${esc(currentAmb.vehicle_number)}</strong>
    &nbsp;|&nbsp; ${esc(currentAmb.hospital_name)}
    &nbsp;|&nbsp; Driver: ${esc(currentAmb.driver_name)}
    &nbsp;|&nbsp; <code>${esc(currentAmb.unique_id)}</code>
  `;
  document.getElementById('amb-info').classList.remove('hidden');

  // Enable map-point buttons
  document.getElementById('btn-start').disabled      = false;
  document.getElementById('btn-dest').disabled       = false;
  document.getElementById('btn-add-signal').disabled = false;
  document.getElementById('btn-clear-signals').disabled = false;

  showAlert('success', `✅ Ambulance selected: ${esc(currentAmb.vehicle_number)}`);
}

// ====================================================
// Map pick mode
// ====================================================
function setPickMode(mode) {
  if (!currentAmb) { showAlert('danger', '❌ Select an ambulance first'); return; }
  // Cancel signal pick mode if active
  if (signalPickMode) toggleSignalPickMode();
  pickMode = mode;
  map.getContainer().style.cursor = 'crosshair';
  const hint = document.getElementById('map-hint');
  hint.classList.remove('hidden');
  document.getElementById('hint-text').textContent =
    mode === 'start'
      ? '📍 Click the map to set the START point.'
      : '🏥 Click the map to set the DESTINATION.';
}

// ====================================================
// Manual signal placement
// ====================================================
function toggleSignalPickMode() {
  if (!currentAmb) { showAlert('danger', '❌ Select an ambulance first'); return; }
  if (activeEmerID && !signalPickMode) { showAlert('warning', '⚠️ Corridor is active — signals can no longer be added.'); return; }

  signalPickMode = !signalPickMode;
  const btn  = document.getElementById('btn-add-signal');
  const hint = document.getElementById('manual-hint');

  if (signalPickMode) {
    // Cancel start/dest pick if running
    pickMode = null;
    document.getElementById('map-hint').classList.add('hidden');

    btn.classList.add('picking');
    btn.textContent = '⛔ Stop adding signals';
    hint.classList.remove('hidden');
    map.getContainer().style.cursor = 'cell';
  } else {
    btn.classList.remove('picking');
    btn.innerHTML = '🚦 Add signal on map';
    hint.classList.add('hidden');
    map.getContainer().style.cursor = '';
  }
}

function removeManualSignal(sig) {
  if (activeEmerID) { showAlert('warning', '⚠️ Corridor is active — cannot remove signals now.'); return; }
  const idx = manualSignals.indexOf(sig);
  if (idx === -1) return;
  if (sig._marker) map.removeLayer(sig._marker);
  manualSignals.splice(idx, 1);
  // Re-number remaining
  manualSignals.forEach((s, i) => {
    s.name = `Manual signal ${i + 1}`;
    if (s._marker) s._marker.setIcon(makeSignalIcon('M' + (i + 1), '#e67e00'));
  });
  refreshSignals();
}

function clearManualSignals() {
  if (activeEmerID) { showAlert('warning', '⚠️ Corridor is active — cannot remove signals now.'); return; }
  manualSignals.forEach(s => { if (s._marker) map.removeLayer(s._marker); });
  manualSignals = [];
  refreshSignals();
  showAlert('success', '✅ All manual signals removed.');
}

// Rebuild combined `signals` array + sidebar list + counts
function refreshSignals() {
  signals = [...osmSignals, ...manualSignals];

  const total = signals.length;
  document.getElementById('route-signals').textContent = total;
  const countEl = document.getElementById('signal-count-text');
  if (countEl) countEl.textContent = total;

  buildSignalList(corridorGreenUpTo);
}

// Colour marker of combined-signal index i (OSM signals come first, so index lines up with signalLayers)
function setSignalMarkerColor(i, color) {
  const s = signals[i];
  if (!s) return;
  if (s.manual) {
    if (s._marker) s._marker.setIcon(makeSignalIcon('M' + (manualSignals.indexOf(s) + 1), color));
  } else if (signalLayers[i]) {
    signalLayers[i].setIcon(makeSignalIcon(i + 1, color));
  }
}

function onMapClick(e) {
  // ── Manual signal placement ──────────────────────
  if (signalPickMode) {
    const num  = manualSignals.length + 1;
    const sig  = {
      lat    : e.latlng.lat,
      lng    : e.latlng.lng,
      name   : `Manual signal ${num}`,
      manual : true
    };
    manualSignals.push(sig);

    // Drop a draggable marker immediately
    const m = L.marker([sig.lat, sig.lng], {
      icon     : makeSignalIcon('M' + num, '#e67e00'),
      draggable: true,
      title    : 'Manual signal — drag to adjust'
    }).addTo(map);

    const popup = document.createElement('div');
    popup.innerHTML = '<b>🚦 Manual signal</b><br><small>Drag to reposition.<br>' +
                      '<a href="#" style="color:#dc3545;">✕ Remove</a></small>';
    popup.querySelector('a').addEventListener('click', ev => {
      ev.preventDefault();
      map.closePopup();
      removeManualSignal(sig);
    });
    m.bindPopup(popup);

    // Update position when dragged
    m.on('dragend', ev => {
      sig.lat = ev.target.getLatLng().lat;
      sig.lng = ev.target.getLatLng().lng;
    });

    sig._marker = m;   // keep ref for removal
    refreshSignals();
    return;
  }

  // ── Start / Dest picking ─────────────────────────
  if (!pickMode) return;
  const latlng = e.latlng;

  if (pickMode === 'start') {
    startLatLng = latlng;
    if (startMarker) map.removeLayer(startMarker);
    startMarker = L.marker(latlng, { icon: makeIcon('#28a745', 'A') })
                   .addTo(map)
                   .bindPopup('<b>Start</b>').openPopup();
  } else {
    destLatLng = latlng;
    if (destMarker) map.removeLayer(destMarker);
    destMarker = L.marker(latlng, { icon: makeIcon('#dc3545', 'B') })
                  .addTo(map)
                  .bindPopup('<b>Destination</b>').openPopup();
  }

  pickMode = null;
  map.getContainer().style.cursor = '';
  document.getElementById('map-hint').classList.add('hidden');

  // Show calculate button once both points are set
  if (startLatLng && destLatLng) {
    document.getElementById('calc-row').style.display = 'block';
  }
}

// ====================================================
// Custom marker icon (SVG circle)
// ====================================================
function makeIcon(color, label) {
  return L.divIcon({
    className: '',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    html: `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="40" viewBox="0 0 32 40">
      <path d="M16 0 C7 0 0 7 0 16 C0 28 16 40 16 40 C16 40 32 28 32 16 C32 7 25 0 16 0Z" fill="${color}"/>
      <circle cx="16" cy="15" r="7" fill="white"/>
      <text x="16" y="19" text-anchor="middle" font-size="11" font-weight="bold" fill="${color}">${label}</text>
    </svg>`
  });
}

function makeSignalIcon(num, color) {
  return L.divIcon({
    className: '',
    iconSize: [26, 26],
    iconAnchor: [13, 13],
    html: `<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26">
      <circle cx="13" cy="13" r="12" fill="${color}" stroke="white" stroke-width="2"/>
      <text x="13" y="18" text-anchor="middle" font-size="11" font-weight="bold" fill="white">${num}</text>
    </svg>`
  });
}

function makeAmbIcon() {
  return L.divIcon({
    className: 'amb-icon-pulse',
    iconSize: [32, 32],
    iconAnchor: [16, 16],
    html: `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
      <circle cx="16" cy="16" r="15" fill="#1a73e8" stroke="white" stroke-width="2"/>
      <text x="16" y="22" text-anchor="middle" font-size="18">🚑</text>
    </svg>`
  });
}

// ====================================================
// Route calculation  (OSRM)
// ====================================================
async function calculateRoute() {
  if (!startLatLng || !destLatLng) { showAlert('danger', '❌ Set both start and destination first'); return; }

  const btn = document.getElementById('calc-btn');
  btn.disabled = true;
  btn.textContent = '⏳ Calculating…';

  // OSRM public API
  const url = `https://router.project-osrm.org/route/v1/driving/` +
    `${startLatLng.lng},${startLatLng.lat};${destLatLng.lng},${destLatLng.lat}` +
    `?overview=full&geometries=geojson&steps=true`;

  try {
    const res  = await fetch(url);
    const json = await res.json();

    if (!json.routes || json.routes.length === 0) {
      showAlert('danger', '❌ No route found. Try different points.');
      btn.disabled = false; btn.textContent = '🗺️ Calculate Route';
      return;
    }

    const route    = json.routes[0];
    const distKm   = (route.distance / 1000).toFixed(2);
    const durMin   = Math.ceil(route.duration / 60);
    const coords   = route.geometry.coordinates.map(([lng, lat]) => [lat, lng]);

    routeData = {
      coords,
      distance : distKm + ' km',
      duration : durMin + ' min',
      source_lat : startLatLng.lat,
      source_lng : startLatLng.lng,
      dest_lat   : destLatLng.lat,
      dest_lng   : destLatLng.lng,
      source_address : `${startLatLng.lat.toFixed(5)}, ${startLatLng.lng.toFixed(5)}`,
      dest_address   : `${destLatLng.lat.toFixed(5)}, ${destLatLng.lng.toFixed(5)}`,
      polyline   : JSON.stringify(coords)
    };

    // Draw route
    if (routeLayer) map.removeLayer(routeLayer);
    routeLayer = L.polyline(coords, { color: '#1a73e8', weight: 6, opacity: 0.85 }).addTo(map);
    map.fitBounds(routeLayer.getBounds(), { padding: [40, 40] });

    document.getElementById('route-distance').textContent = routeData.distance;
    document.getElementById('route-duration').textContent = routeData.duration;

    // Fetch traffic signals
    await fetchSignals(route);

    document.getElementById('route-info').classList.remove('hidden');
    document.getElementById('corridor-status').textContent = 'READY';

    btn.textContent = '🗺️ Recalculate Route';
    btn.disabled = false;

  } catch (err) {
    showAlert('danger', '❌ Route calculation failed: ' + err.message);
    btn.disabled = false; btn.textContent = '🗺️ Calculate Route';
  }
}

// ====================================================
// Fetch traffic signals from Overpass API
// ====================================================
async function fetchSignals(osrmRoute) {
  // Clear old OSM signal markers (manual ones stay)
  signalLayers.forEach(l => map.removeLayer(l));
  signalLayers = [];
  osmSignals = [];

  // Build bounding box from route geometry
  const coords = osrmRoute.geometry.coordinates; // [lng,lat]
  let minLat =  90, maxLat = -90, minLng = 180, maxLng = -180;
  coords.forEach(([lng, lat]) => {
    if (lat < minLat) minLat = lat;
    if (lat > maxLat) maxLat = lat;
    if (lng < minLng) minLng = lng;
    if (lng > maxLng) maxLng = lng;
  });
  // Add a small buffer
  const buf = 0.005;
  const bbox = `${minLat - buf},${minLng - buf},${maxLat + buf},${maxLng + buf}`;

  const overpassQuery = `
    [out:json][timeout:25];
    node["highway"="traffic_signals"](${bbox});
    out body;
  `;

  try {
    const res  = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'data=' + encodeURIComponent(overpassQuery)
    });
    if (!res.ok) throw new Error('Overpass HTTP ' + res.status);
    const json  = await res.json();
    const nodes = json.elements || [];

    // Keep signals within ~80m of the route and order them along the route
    const found = [];
    nodes.forEach(node => {
      const hit = nearestRouteIdx(node.lat, node.lon, routeData.coords);
      if (hit.d2 < 0.0008 * 0.0008) {
        found.push({ lat: node.lat, lng: node.lon, name: node.tags?.name || 'Traffic signal', _idx: hit.idx });
      }
    });
    found.sort((a, b) => a._idx - b._idx);
    osmSignals = found.map((s, i) => ({ ...s, id: i + 1, name: s.name === 'Traffic signal' ? `Signal #${i + 1}` : s.name }));

  } catch (e) {
    // Overpass is slow or offline – continue with manual signals only
    console.warn('Overpass error:', e.message);
    showAlert('warning', '⚠️ Could not load traffic signals from OpenStreetMap. You can still add signals manually.');
  }

  renderSignalMarkers('#dc3545');
  refreshSignals();
}

// Index of the route point closest to (lat,lng) + squared distance in degrees
function nearestRouteIdx(lat, lng, routeCoords) {
  let best = 0, bestD2 = Infinity;
  for (let i = 0; i < routeCoords.length; i++) {
    const dLat = routeCoords[i][0] - lat;
    const dLng = routeCoords[i][1] - lng;
    const d2 = dLat * dLat + dLng * dLng;
    if (d2 < bestD2) { bestD2 = d2; best = i; }
  }
  return { idx: best, d2: bestD2 };
}

function renderSignalMarkers(color) {
  signalLayers.forEach(l => map.removeLayer(l));
  signalLayers = [];
  osmSignals.forEach((s, i) => {
    const m = L.marker([s.lat, s.lng], { icon: makeSignalIcon(i + 1, color) })
               .addTo(map)
               .bindPopup(`<b>🚦 Signal #${i + 1}</b><br>${esc(s.name)}`);
    signalLayers.push(m);
  });
  manualSignals.forEach((s, i) => {
    if (s._marker) s._marker.setIcon(makeSignalIcon('M' + (i + 1), color === '#dc3545' ? '#e67e00' : color));
  });
}

function buildSignalList(greenUpTo = -1) {
  const container = document.getElementById('signal-list');
  if (signals.length === 0) {
    container.innerHTML = '<div style="padding:1rem;text-align:center;color:var(--gray);">No signals on this route yet — add some manually if needed</div>';
    return;
  }
  container.innerHTML = '';
  signals.forEach((s, i) => {
    const isGreen = i <= greenUpTo;
    const row = document.createElement('div');
    row.className = 'signal-item';
    row.innerHTML = `
      <div class="signal-dot ${isGreen ? 'green' : ''}" id="dot-${i}"></div>
      <strong>#${i + 1}</strong>
      <span style="flex:1;">${esc(s.name)}${s.manual ? '<span class="manual-badge">manual</span>' : ''}</span>
      <span id="lbl-${i}" style="color:${isGreen ? 'green' : 'var(--danger)'};font-size:0.8rem;font-weight:600;">${isGreen ? '🟢 GREEN' : '🔴 Red'}</span>
      ${s.manual && !activeEmerID ? '<a href="#" class="rm" style="font-size:0.8rem;color:var(--danger);">✕</a>' : ''}
    `;
    const rm = row.querySelector('a.rm');
    if (rm) rm.addEventListener('click', ev => { ev.preventDefault(); removeManualSignal(s); });
    container.appendChild(row);
  });
}

// ====================================================
// EMERGENCY  –  start immediately, no admin approval
// ====================================================
async function triggerEmergency() {
  if (!currentAmb || !routeData) { showAlert('danger', '❌ Calculate the route first'); return; }

  const btn = document.getElementById('emergency-btn');
  btn.disabled = true;

  const body = {
    unique_id         : currentAmb.unique_id,
    source_address    : routeData.source_address,
    source_lat        : routeData.source_lat,
    source_lng        : routeData.source_lng,
    destination_address: routeData.dest_address,
    destination_lat   : routeData.dest_lat,
    destination_lng   : routeData.dest_lng,
    route_distance    : routeData.distance,
    route_duration    : routeData.duration,
    route_polyline    : routeData.polyline,
    signals_count     : signals.length,
    signals_data      : signals.map((s, i) => ({ id: i + 1, lat: s.lat, lng: s.lng, name: s.name, manual: !!s.manual })),
    priority          : document.getElementById('priority').value,
    auto_approve      : true
  };

  try {
    const res    = await fetch(`${API}/api/emergency/trigger`, {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(body)
    });
    const result = await res.json();

    if (!res.ok) { showAlert('danger', `❌ ${esc(result.error)}`); btn.disabled = false; return; }

    activeEmerID = result.emergency.id;

    // Activate corridor immediately
    const apr = await fetch(`${API}/api/admin/emergency/${activeEmerID}/approve`, {
      method : 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ admin_notes: 'Auto-activated by driver' })
    });
    if (!apr.ok) {
      const err = await apr.json().catch(() => ({}));
      showAlert('danger', `❌ Could not activate corridor: ${esc(err.error || apr.status)}`);
      activeEmerID = null;
      btn.disabled = false;
      return;
    }

    // Update UI
    document.getElementById('active-banner').style.display = 'block';
    document.getElementById('corridor-status').textContent = '🟢 ACTIVE';
    document.getElementById('corridor-status').style.color = 'var(--success)';
    document.getElementById('cancel-btn').style.display    = 'block';
    btn.style.display = 'none';

    // Green route
    if (routeLayer) map.removeLayer(routeLayer);
    routeLayer = L.polyline(routeData.coords, { color: '#00cc00', weight: 8, opacity: 0.9 }).addTo(map);

    // All signals green immediately
    renderSignalMarkers('#00cc00');
    corridorGreenUpTo = signals.length - 1;
    buildSignalList(corridorGreenUpTo);
    document.title = '🟢 GREEN CORRIDOR ACTIVE — Ambulance Signal System';

    // Simulate drive if checked
    if (document.getElementById('sim-check').checked) {
      startSimulation();
    }

  } catch (err) {
    showAlert('danger', '❌ Network error: ' + err.message);
    btn.disabled = false;
  }
}

// ====================================================
// Cancel Emergency
// ====================================================
async function cancelEmergency() {
  if (!activeEmerID) return;
  if (!confirm('Cancel the emergency and release all signals back to normal?')) return;

  try {
    await fetch(`${API}/api/admin/emergency/${activeEmerID}/deactivate-corridor`, {
      method: 'PUT'
    });
  } catch (e) { /* best effort */ }

  stopSimulation();
  resetDriver();
  showAlert('success', '✅ Emergency cancelled. Signals restored to normal.');
}

// ====================================================
// Simulation
// ====================================================
function startSimulation() {
  const coords  = routeData.coords;
  const total   = coords.length;
  simStep       = 0;

  const progress = document.getElementById('sim-progress');
  const simLabel = document.getElementById('sim-label');
  progress.style.display = 'inline';
  simLabel.style.display = 'inline';
  progress.max   = total - 1;

  // Place ambulance marker at start
  if (ambMarker) map.removeLayer(ambMarker);
  ambMarker = L.marker(coords[0], { icon: makeAmbIcon(), zIndexOffset: 1000 })
               .addTo(map)
               .bindPopup('🚑 Ambulance');

  // Which route point is each signal closest to?
  signals.forEach(sg => { sg._idx = nearestRouteIdx(sg.lat, sg.lng, coords).idx; });

  simInterval = setInterval(() => {
    if (simStep >= total - 1) { stopSimulation(); return; }
    simStep++;
    const pos = coords[simStep];
    ambMarker.setLatLng(pos);
    progress.value = simStep;
    simLabel.textContent = `${Math.round((simStep / (total - 1)) * 100)}%`;

    // Signals the ambulance has passed go back to normal, the rest stay green
    signals.forEach((sg, i) => {
      const dot = document.getElementById(`dot-${i}`);
      const lbl = document.getElementById(`lbl-${i}`);
      if (!dot) return;
      if (sg._idx < simStep) {
        dot.classList.remove('green');
        if (lbl) { lbl.textContent = '⚫ Passed'; lbl.style.color = 'var(--gray)'; }
        setSignalMarkerColor(i, '#6c757d');
      } else {
        dot.classList.add('green');
        if (lbl) { lbl.textContent = '🟢 GREEN'; lbl.style.color = 'green'; }
        setSignalMarkerColor(i, '#00cc00');
      }
    });

    map.panTo(pos, { animate: true, duration: 0.3 });
  }, 80);
}

function stopSimulation() {
  if (simInterval) { clearInterval(simInterval); simInterval = null; }
  document.getElementById('sim-progress').style.display = 'none';
  document.getElementById('sim-label').style.display    = 'none';
}

// Haversine distance in km
function haversineKm(lat1, lng1, lat2, lng2) {
  const R   = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a   = Math.sin(dLat/2)**2 +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ====================================================
// Reset
// ====================================================
function resetDriver() {
  stopSimulation();

  if (startMarker) { map.removeLayer(startMarker); startMarker = null; }
  if (destMarker)  { map.removeLayer(destMarker);  destMarker  = null; }
  if (routeLayer)  { map.removeLayer(routeLayer);  routeLayer  = null; }
  if (ambMarker)   { map.removeLayer(ambMarker);   ambMarker   = null; }
  signalLayers.forEach(l => map.removeLayer(l));
  signalLayers = [];
  manualSignals.forEach(sg => { if (sg._marker) map.removeLayer(sg._marker); });
  manualSignals = [];
  osmSignals = [];
  signals = [];
  corridorGreenUpTo = -1;

  startLatLng = destLatLng = routeData = null;
  activeEmerID = null;
  pickMode = null;
  document.getElementById('signal-list').innerHTML = '';
  document.getElementById('route-signals').textContent = '—';
  document.getElementById('calc-btn').textContent = '🗺️ Calculate Route';
  document.getElementById('calc-btn').disabled = false;

  document.getElementById('active-banner').style.display   = 'none';
  document.getElementById('route-info').classList.add('hidden');
  document.getElementById('calc-row').style.display        = 'none';
  document.getElementById('cancel-btn').style.display      = 'none';
  document.getElementById('emergency-btn').style.display   = '';
  document.getElementById('emergency-btn').disabled        = false;
  document.getElementById('corridor-status').textContent   = 'READY';
  document.getElementById('corridor-status').style.color   = '';
  document.getElementById('map-hint').classList.add('hidden');
  document.title = 'Driver — Ambulance Signal System';
}

// ====================================================
// Alerts
// ====================================================
function showAlert(type, msg) {
  const c = document.getElementById('alert-container');
  c.innerHTML = `<div class="alert alert-${type}">${msg}</div>`;
  setTimeout(() => { c.innerHTML = ''; }, 6000);
}

// ====================================================
// Boot
// ====================================================
initMap();
loadAmbulances();
