const API = location.protocol === 'file:' ? 'http://localhost:3000' : '';

function showAlert(containerId, type, message) {
  const container = document.getElementById(containerId);
  container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
  setTimeout(() => { container.innerHTML = ''; }, 5000);
}

document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const data = {
    vehicle_number: document.getElementById('vehicle_number').value.trim(),
    hospital_name: document.getElementById('hospital_name').value.trim(),
    area: document.getElementById('area').value.trim(),
    driver_name: document.getElementById('driver_name').value.trim(),
    driver_phone: document.getElementById('driver_phone').value.trim(),
    vehicle_type: document.getElementById('vehicle_type').value,
  };

  // Basic validation
  if (!data.vehicle_number || !data.hospital_name || !data.area || !data.driver_name || !data.driver_phone) {
    showAlert('alert-container', 'danger', '❌ Please fill in all required fields');
    return;
  }

  if (data.driver_phone.length < 10) {
    showAlert('alert-container', 'danger', '❌ Please enter a valid phone number');
    return;
  }

  try {
    const submitBtn = document.querySelector('#registerForm button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = '⏳ Registering...';

    const response = await fetch(`${API}/api/ambulances/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (response.ok) {
      // Hide form, show success
      document.getElementById('registerForm').classList.add('hidden');
      document.getElementById('success-section').classList.remove('hidden');
      document.getElementById('display-uid').textContent = result.ambulance.unique_id;
    } else {
      showAlert('alert-container', 'danger', `❌ ${result.error}`);
      submitBtn.disabled = false;
      submitBtn.textContent = '🚑 Register Ambulance';
    }
  } catch (error) {
    showAlert('alert-container', 'danger', '❌ Network error. Please try again.');
    const submitBtn = document.querySelector('#registerForm button[type="submit"]');
    submitBtn.disabled = false;
    submitBtn.textContent = '🚑 Register Ambulance';
  }
});

function resetForm() {
  document.getElementById('registerForm').reset();
  document.getElementById('registerForm').classList.remove('hidden');
  document.getElementById('success-section').classList.add('hidden');
  document.getElementById('alert-container').innerHTML = '';
}
