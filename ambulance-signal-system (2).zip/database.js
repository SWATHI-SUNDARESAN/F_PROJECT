const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'ambulance.db'));

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS ambulances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unique_id TEXT UNIQUE NOT NULL,
    vehicle_number TEXT UNIQUE NOT NULL,
    hospital_name TEXT NOT NULL,
    area TEXT NOT NULL,
    driver_name TEXT NOT NULL,
    driver_phone TEXT NOT NULL,
    vehicle_type TEXT DEFAULT 'Basic Life Support',
    registered_at TEXT DEFAULT (datetime('now')),
    status TEXT DEFAULT 'active'
  );

  CREATE TABLE IF NOT EXISTS emergency_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ambulance_id INTEGER NOT NULL,
    unique_id TEXT NOT NULL,
    source_address TEXT,
    source_lat REAL,
    source_lng REAL,
    destination_address TEXT,
    destination_lat REAL,
    destination_lng REAL,
    route_distance TEXT,
    route_duration TEXT,
    route_polyline TEXT,
    signals_count INTEGER DEFAULT 0,
    signals_data TEXT,
    priority TEXT DEFAULT 'high',
    signal_status TEXT DEFAULT 'pending',
    corridor_status TEXT DEFAULT 'inactive',
    requested_at TEXT DEFAULT (datetime('now')),
    responded_at TEXT,
    admin_notes TEXT,
    FOREIGN KEY (ambulance_id) REFERENCES ambulances(id)
  );

  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS signal_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    emergency_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    performed_by TEXT,
    performed_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (emergency_id) REFERENCES emergency_requests(id)
  );
`);

// Insert default admin if not exists
const adminExists = db.prepare('SELECT COUNT(*) as count FROM admins').get();
if (adminExists.count === 0) {
  db.prepare('INSERT INTO admins (username, password, name) VALUES (?, ?, ?)').run(
    'admin', 'admin123', 'System Administrator'
  );
}

module.exports = db;
