const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ==================== USER ROUTES ====================

// Register a new ambulance
app.post('/api/ambulances/register', (req, res) => {
  try {
    const { vehicle_number, hospital_name, area, driver_name, driver_phone, vehicle_type } = req.body;

    if (!vehicle_number || !hospital_name || !area || !driver_name || !driver_phone) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const unique_id = 'AMB-' + uuidv4().split('-')[0].toUpperCase();

    const stmt = db.prepare(`
      INSERT INTO ambulances (unique_id, vehicle_number, hospital_name, area, driver_name, driver_phone, vehicle_type)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(unique_id, vehicle_number.toUpperCase(), hospital_name, area, driver_name, driver_phone, vehicle_type || 'Basic Life Support');

    res.status(201).json({
      message: 'Ambulance registered successfully!',
      ambulance: {
        id: result.lastInsertRowid,
        unique_id,
        vehicle_number: vehicle_number.toUpperCase(),
        hospital_name,
        area,
        driver_name,
        driver_phone,
        vehicle_type: vehicle_type || 'Basic Life Support'
      }
    });
  } catch (err) {
    if (err.message.includes('UNIQUE constraint failed')) {
      return res.status(409).json({ error: 'This vehicle number is already registered' });
    }
    res.status(500).json({ error: 'Registration failed: ' + err.message });
  }
});

// Lookup ambulance by unique ID
app.get('/api/ambulances/lookup/:uniqueId', (req, res) => {
  try {
    const ambulance = db.prepare('SELECT * FROM ambulances WHERE unique_id = ? AND status = ?').get(req.params.uniqueId, 'active');
    if (!ambulance) {
      return res.status(404).json({ error: 'Ambulance not found or inactive' });
    }
    res.json(ambulance);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Trigger emergency request (with route and signals data)
app.post('/api/emergency/trigger', (req, res) => {
  try {
    const {
      unique_id,
      source_address, source_lat, source_lng,
      destination_address, destination_lat, destination_lng,
      route_distance, route_duration, route_polyline,
      signals_count, signals_data,
      priority
    } = req.body;

    if (!unique_id) {
      return res.status(400).json({ error: 'Ambulance unique ID is required' });
    }

    // Verify ambulance exists and is active
    const ambulance = db.prepare('SELECT * FROM ambulances WHERE unique_id = ? AND status = ?').get(unique_id, 'active');
    if (!ambulance) {
      return res.status(404).json({ error: 'Ambulance not found or not registered. Please register first.' });
    }

    // Check if there's already a pending emergency for this ambulance
    const pendingEmergency = db.prepare(
      'SELECT * FROM emergency_requests WHERE unique_id = ? AND signal_status = ?'
    ).get(unique_id, 'pending');

    if (pendingEmergency) {
      return res.status(409).json({ error: 'There is already a pending emergency request for this ambulance' });
    }

    const stmt = db.prepare(`
      INSERT INTO emergency_requests (
        ambulance_id, unique_id,
        source_address, source_lat, source_lng,
        destination_address, destination_lat, destination_lng,
        route_distance, route_duration, route_polyline,
        signals_count, signals_data, priority
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      ambulance.id, unique_id,
      source_address || '', source_lat || 0, source_lng || 0,
      destination_address || '', destination_lat || 0, destination_lng || 0,
      route_distance || '', route_duration || '', route_polyline || '',
      signals_count || 0, signals_data ? JSON.stringify(signals_data) : '[]',
      priority || 'high'
    );

    res.status(201).json({
      message: 'Emergency request sent! Waiting for admin verification...',
      emergency: {
        id: result.lastInsertRowid,
        unique_id,
        hospital_name: ambulance.hospital_name,
        vehicle_number: ambulance.vehicle_number,
        signal_status: 'pending',
        signals_count: signals_count || 0
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Emergency trigger failed: ' + err.message });
  }
});

// Check emergency status (for user polling)
app.get('/api/emergency/status/:uniqueId', (req, res) => {
  try {
    const emergency = db.prepare(`
      SELECT er.*, a.hospital_name, a.vehicle_number, a.area, a.driver_name
      FROM emergency_requests er
      JOIN ambulances a ON er.ambulance_id = a.id
      WHERE er.unique_id = ?
      ORDER BY er.id DESC
      LIMIT 1
    `).get(req.params.uniqueId);

    if (!emergency) {
      return res.status(404).json({ error: 'No emergency request found' });
    }

    // Parse signals_data if it's a string
    if (emergency.signals_data && typeof emergency.signals_data === 'string') {
      try {
        emergency.signals_data = JSON.parse(emergency.signals_data);
      } catch (e) {
        emergency.signals_data = [];
      }
    }

    res.json(emergency);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== ADMIN ROUTES ====================

// Admin login
app.post('/api/admin/login', (req, res) => {
  try {
    const { username, password } = req.body;
    const admin = db.prepare('SELECT * FROM admins WHERE username = ? AND password = ?').get(username, password);

    if (!admin) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    res.json({ message: 'Login successful', admin: { id: admin.id, name: admin.name, username: admin.username } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all registered ambulances
app.get('/api/admin/ambulances', (req, res) => {
  try {
    const ambulances = db.prepare('SELECT * FROM ambulances ORDER BY registered_at DESC').all();
    res.json(ambulances);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all emergency requests
app.get('/api/admin/emergencies', (req, res) => {
  try {
    const emergencies = db.prepare(`
      SELECT er.*, a.hospital_name, a.vehicle_number, a.area, a.driver_name, a.driver_phone, a.vehicle_type
      FROM emergency_requests er
      JOIN ambulances a ON er.ambulance_id = a.id
      ORDER BY 
        CASE er.signal_status WHEN 'pending' THEN 0 ELSE 1 END,
        er.requested_at DESC
    `).all();

    // Parse signals_data for each
    emergencies.forEach(em => {
      if (em.signals_data && typeof em.signals_data === 'string') {
        try { em.signals_data = JSON.parse(em.signals_data); } catch (e) { em.signals_data = []; }
      }
    });

    res.json(emergencies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single emergency detail (for admin map view)
app.get('/api/admin/emergency/:id', (req, res) => {
  try {
    const emergency = db.prepare(`
      SELECT er.*, a.hospital_name, a.vehicle_number, a.area, a.driver_name, a.driver_phone, a.vehicle_type
      FROM emergency_requests er
      JOIN ambulances a ON er.ambulance_id = a.id
      WHERE er.id = ?
    `).get(req.params.id);

    if (!emergency) {
      return res.status(404).json({ error: 'Not found' });
    }

    if (emergency.signals_data && typeof emergency.signals_data === 'string') {
      try { emergency.signals_data = JSON.parse(emergency.signals_data); } catch (e) { emergency.signals_data = []; }
    }

    res.json(emergency);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get dashboard stats
app.get('/api/admin/stats', (req, res) => {
  try {
    const totalAmbulances = db.prepare('SELECT COUNT(*) as count FROM ambulances WHERE status = ?').get('active');
    const totalEmergencies = db.prepare('SELECT COUNT(*) as count FROM emergency_requests').get();
    const pendingEmergencies = db.prepare('SELECT COUNT(*) as count FROM emergency_requests WHERE signal_status = ?').get('pending');
    const approvedToday = db.prepare(
      "SELECT COUNT(*) as count FROM emergency_requests WHERE signal_status = 'green_signal' AND date(responded_at) = date('now')"
    ).get();
    const activeCorridors = db.prepare(
      "SELECT COUNT(*) as count FROM emergency_requests WHERE corridor_status = 'active'"
    ).get();

    res.json({
      totalAmbulances: totalAmbulances.count,
      totalEmergencies: totalEmergencies.count,
      pendingEmergencies: pendingEmergencies.count,
      approvedToday: approvedToday.count,
      activeCorridors: activeCorridors.count
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Approve emergency - Activate GREEN CORRIDOR for ALL signals
app.put('/api/admin/emergency/:id/approve', (req, res) => {
  try {
    const { admin_notes } = req.body;
    const emergency = db.prepare('SELECT * FROM emergency_requests WHERE id = ?').get(req.params.id);

    if (!emergency) {
      return res.status(404).json({ error: 'Emergency request not found' });
    }

    if (emergency.signal_status !== 'pending') {
      return res.status(400).json({ error: 'This request has already been processed' });
    }

    // Update emergency status to green signal + activate corridor
    db.prepare(`
      UPDATE emergency_requests 
      SET signal_status = 'green_signal', 
          corridor_status = 'active',
          responded_at = datetime('now'), 
          admin_notes = ?
      WHERE id = ?
    `).run(admin_notes || 'Approved - Green Corridor Activated', req.params.id);

    // Log the action
    db.prepare(`
      INSERT INTO signal_log (emergency_id, action, performed_by)
      VALUES (?, 'GREEN_CORRIDOR_ACTIVATED', 'admin')
    `).run(req.params.id);

    const signalsCount = emergency.signals_count || 0;

    res.json({
      message: `🟢 GREEN CORRIDOR activated! ${signalsCount} signals set to GREEN.`,
      signal_status: 'green_signal',
      corridor_status: 'active',
      signals_count: signalsCount,
      hardware_command: 'ACTIVATE_GREEN_CORRIDOR'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Deactivate corridor (after ambulance has passed)
app.put('/api/admin/emergency/:id/deactivate-corridor', (req, res) => {
  try {
    db.prepare(`
      UPDATE emergency_requests 
      SET corridor_status = 'completed'
      WHERE id = ?
    `).run(req.params.id);

    db.prepare(`
      INSERT INTO signal_log (emergency_id, action, performed_by)
      VALUES (?, 'CORRIDOR_DEACTIVATED', 'admin')
    `).run(req.params.id);

    res.json({
      message: 'Green corridor deactivated. Signals restored to normal.',
      corridor_status: 'completed',
      hardware_command: 'DEACTIVATE_GREEN_CORRIDOR'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Reject emergency
app.put('/api/admin/emergency/:id/reject', (req, res) => {
  try {
    const { admin_notes } = req.body;
    const emergency = db.prepare('SELECT * FROM emergency_requests WHERE id = ?').get(req.params.id);

    if (!emergency) {
      return res.status(404).json({ error: 'Emergency request not found' });
    }

    if (emergency.signal_status !== 'pending') {
      return res.status(400).json({ error: 'This request has already been processed' });
    }

    db.prepare(`
      UPDATE emergency_requests 
      SET signal_status = 'rejected', responded_at = datetime('now'), admin_notes = ?
      WHERE id = ?
    `).run(admin_notes || 'Rejected', req.params.id);

    db.prepare(`
      INSERT INTO signal_log (emergency_id, action, performed_by)
      VALUES (?, 'REJECTED', 'admin')
    `).run(req.params.id);

    res.json({
      message: '🔴 Emergency request rejected.',
      signal_status: 'rejected',
      hardware_command: 'SIGNAL_STAY_RED'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Deactivate ambulance
app.put('/api/admin/ambulance/:id/deactivate', (req, res) => {
  try {
    db.prepare('UPDATE ambulances SET status = ? WHERE id = ?').run('inactive', req.params.id);
    res.json({ message: 'Ambulance deactivated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Hardware integration - Returns ALL active corridor signals
app.get('/api/hardware/signal-status', (req, res) => {
  try {
    const activeCorridors = db.prepare(`
      SELECT er.*, a.vehicle_number, a.hospital_name
      FROM emergency_requests er
      JOIN ambulances a ON er.ambulance_id = a.id
      WHERE er.corridor_status = 'active'
      ORDER BY er.responded_at DESC
    `).all();

    if (activeCorridors.length > 0) {
      const corridors = activeCorridors.map(c => {
        let signals = [];
        if (c.signals_data) {
          try { signals = JSON.parse(c.signals_data); } catch (e) { signals = []; }
        }
        return {
          emergency_id: c.id,
          vehicle_number: c.vehicle_number,
          hospital: c.hospital_name,
          source: c.source_address,
          destination: c.destination_address,
          distance: c.route_distance,
          duration: c.route_duration,
          signals_count: c.signals_count,
          signals: signals,
          command: 'ALL_GREEN'
        };
      });

      res.json({
        status: 'GREEN_CORRIDOR_ACTIVE',
        active_corridors: corridors.length,
        corridors
      });
    } else {
      res.json({
        status: 'NORMAL',
        active_corridors: 0,
        command: 'MAINTAIN_NORMAL'
      });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== SERVE PAGES ====================
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/emergency', (req, res) => res.sendFile(path.join(__dirname, 'public', 'emergency.html')));
app.get('/driver', (req, res) => res.sendFile(path.join(__dirname, 'public', 'driver.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

app.listen(PORT, () => {
  console.log(`\n🚑 Ambulance Signal System running at http://localhost:${PORT}`);
  console.log(`   📋 Register:  http://localhost:${PORT}/register`);
  console.log(`   🚨 Emergency: http://localhost:${PORT}/emergency`);
  console.log(`   🔐 Admin:     http://localhost:${PORT}/admin`);
  console.log(`\n   Default Admin → username: admin, password: admin123\n`);
});
